from .lhapdf import *
__version__ = version()
