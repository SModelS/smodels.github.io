# Release 2.x-dev (development release)

## New features since last release

## Improvements

## Bug fixes

## Contributors

This release contains contributions from (in alphabetical order):
