# Contributors

MadAnalysis is openly developed and benefits from contributions and feedback
from its users. The MA5-dev team would like to thank all contributors to the
project for their support and help during the last decade (yes we are that old
already).

Thank you!

Our contributors (alphabetically) include:
- Gael Alguero
- Beranger Dumont
- [Kyle Fan](https://github.com/kfan326)
- Sabine Kraml
- Mark Goodsell
- Valentin Hirschi
- Olivier Mattelaer
- Thibaut Schmitt
- Guillaume Serret
- Manuel Utsch
- Wolfgang Waltenberger
- Chris Wymant
