smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : '/home/yoxara/smodels/smodels-database/8TeV/ATLAS/ATLAS-EXOT-2013-11/validation/slhaFiles/run_01_tag_1.slha',
    'promptwidth' : 1e-14,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 0,
    'warnings' : 'Input file ok',
    'input file' : '/home/yoxara/smodels/smodels-database/8TeV/ATLAS/ATLAS-EXOT-2013-11/validation/slhaFiles/run_12_tag_1_6th.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 101000.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 33600.0}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 33600.0}
    }
],
'Total xsec for missing topologies (fb)' : 33582.0,
'missing topologies' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 33582.0,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [3]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 167910.0,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 134328.0,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 33582.0,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [3]
    }
],
'Total xsec for topologies outside the grid (fb)' : 134328.0,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 134328.0,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    }
]
}