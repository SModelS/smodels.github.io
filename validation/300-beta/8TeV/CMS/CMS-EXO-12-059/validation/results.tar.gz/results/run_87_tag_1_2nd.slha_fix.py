smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 0.5,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : '/home/yoxara/smodels/smodels-database/8TeV/CMS/CMS-EXO-12-059/validation/slhaFiles_Lept_gqp/run_01_tag_1.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '/home/yoxara/smodels/smodels-database/8TeV/CMS/CMS-EXO-12-059/validation/slhaFiles_Lept_gqp/run_87_tag_1_2nd.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 3000.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 166.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 3000.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 55.3}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 3000.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 55.3}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 3000.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 55.3}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 221.3558,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('y1', 3000.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 19.82285,
        'r_expected' : None,
        'Width (GeV)' : [('y1', 'prompt')],
        'TxNames weights (fb)' : {'TRV1qq': 221.35576822}
    }
],
'Total xsec for missing topologies (fb)' : 110.6743,
'missing topologies' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 55.33894,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 55.33532,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 332.03,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 221.3558,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 55.33894,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 55.33532,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}