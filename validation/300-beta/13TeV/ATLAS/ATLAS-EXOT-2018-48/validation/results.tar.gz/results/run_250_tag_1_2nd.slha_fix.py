smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : '/home/yoxara/ATLAS-EXOT-2018-48/validation/slhaFiles_Simp_Axi/run_16_tag_1_3rd.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '/home/yoxara/ATLAS-EXOT-2018-48/validation/slhaFiles_Simp_Axi/run_250_tag_1_2nd.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 4300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 187.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 4300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 62.4}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 4300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 61.8}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 4300.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 62.4}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 61.83414,
        'upper limit (fb)' : 1.9581,
        'expected upper limit (fb)' : 2.43799,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('y1', 4300.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 31.57864,
        'r_expected' : 25.36275,
        'Width (GeV)' : [('y1', 'prompt')],
        'TxNames weights (fb)' : {'TRV1tt': 61.83413813232}
    }
],
'Total xsec for missing topologies (fb)' : 312.1621,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 249.73,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 62.43208,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 373.9962,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 249.73,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 62.43208,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.83414,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}