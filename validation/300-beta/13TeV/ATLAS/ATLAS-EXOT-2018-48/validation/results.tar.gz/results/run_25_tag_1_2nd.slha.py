smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : '/home/yoxara/ATLAS-EXOT-2018-48/validation/slhaFiles_Simp_Axi/run_16_tag_1_3rd.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 0,
    'warnings' : 'Input file ok',
    'input file' : '/home/yoxara/ATLAS-EXOT-2018-48/validation/slhaFiles_Simp_Axi/run_25_tag_1_2nd.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 1700.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 7890.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 1700.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 2630.0}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 1700.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 2470.0}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 1700.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 2630.0}
    }
],
'Total xsec for missing topologies (fb)' : 13154.96,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10524.07,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2630.897,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 15626.05,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10524.07,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2630.897,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2471.086,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
],
'Total xsec for topologies outside the grid (fb)' : 2471.086,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2471.086,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
]
}