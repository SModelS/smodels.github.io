smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : 'TRV1jj_slha/run_01_MZp_1500_gAq_4.000000E-02.slha',
    'promptwidth' : 1.0,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'TRV1jj_slha/run_120_MZp_2200_gAq_1.750000E-01.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 2200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 96.8}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 2200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 32.3}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 2200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 31.1}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 2200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 32.3}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 161.2902,
        'upper limit (fb)' : 34.3726,
        'expected upper limit (fb)' : 37.6792,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('y1', 2200.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 4.692406,
        'r_expected' : 4.280616,
        'Width (GeV)' : [('y1', 3.1974)],
        'TxNames weights (fb)' : {'TRV1jj': 161.29018952760003}
    }
],
'Total xsec for missing topologies (fb)' : 31.08243,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 31.08243,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 192.3726,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 129.0328,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [1, 2]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.25735,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [4]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 31.08243,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [3]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}