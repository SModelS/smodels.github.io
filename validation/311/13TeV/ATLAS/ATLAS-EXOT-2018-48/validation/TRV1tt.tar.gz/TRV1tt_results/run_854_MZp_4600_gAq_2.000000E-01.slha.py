smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : 'TRV1tt_slha/run_91_MZp_1800_gAq_8.200000E-02.slha',
    'promptwidth' : 1.0,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'TRV1tt_slha/run_854_MZp_4600_gAq_2.000000E-01.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1)',
        'Masses (GeV)' : [('y1', 4600.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 1.29}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 4600.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 0.644}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 4600.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 0.215}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 4600.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 0.213}
    },
    {
        'ID' : 5,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 4600.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 0.215}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2129009,
        'upper limit (fb)' : 2.17933,
        'expected upper limit (fb)' : 2.31922,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('y1', 4600.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.097691,
        'r_expected' : 0.09179851,
        'Width (GeV)' : [('y1', 0.01754615)],
        'TxNames weights (fb)' : {'TRV1tt': 0.21290093626370002}
    }
],
'Total xsec for missing topologies (fb)' : 1.073496,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8587977,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.214698,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.286397,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8587977,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.214698,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2129009,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}