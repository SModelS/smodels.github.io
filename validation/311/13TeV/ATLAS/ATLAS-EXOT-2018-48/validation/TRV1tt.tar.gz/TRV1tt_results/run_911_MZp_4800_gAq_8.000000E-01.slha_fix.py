smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : 'TRV1tt_slha/run_91_MZp_1800_gAq_8.200000E-02.slha',
    'promptwidth' : 1.0,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'TRV1tt_slha/run_911_MZp_4800_gAq_8.000000E-01.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1)',
        'Masses (GeV)' : [('y1', 4800.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 13.6}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 4800.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 6.8}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 4800.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 2.27}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 4800.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 2.25}
    },
    {
        'ID' : 5,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 4800.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 13.0 TeV': 2.27}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.248664,
        'upper limit (fb)' : 2.50818,
        'expected upper limit (fb)' : 2.26312,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('y1', 4800.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.8965321,
        'r_expected' : 0.9936123,
        'Width (GeV)' : [('y1', 0.2929778)],
        'TxNames weights (fb)' : {'TRV1tt': 2.2486639523167997}
    }
],
'Total xsec for missing topologies (fb)' : 11.33049,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.064398,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.266087,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 13.57915,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.064398,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.266087,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.248664,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}