#!/usr/bin/env python3

with open('rValues.dat','w') as out:
    out.write('# m2 m1 r_obs r_exp \n')
    with open('summary.txt','r') as file:
        for line in file.readlines():
            if '#' in line : continue
            x = int(line.split()[0].split('_')[1].replace('.slha',''))
            y = int(line.split()[0].split('_')[4].replace('.slha',''))
            z1 = float(line.split()[2])
            z2 = float(line.split()[3])
            out.write('{} {} {} {} \n'.format(x,y,z1,z2))
