smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.005,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 7,
    'model' : 'share.models.mssm',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'ignorepromptqnumbers' : 'spin,eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'testcoverage' : True,
    'computestatistics' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodels-utils/slha/TChi_nonDegenHinoLSP_BRN2toZN1100/TChiWZoffCd2_220_195_207_195.slha',
    'database version' : '2.1.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1339466,
        'upper limit (fb)' : 0.3046218,
        'expected upper limit (fb)' : 0.3595998,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16-hino',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4397144,
        'r_expected' : 0.372488,
        'Width (GeV)' : None,
        'nll' : 1.877021,
        'nll_min' : 1.244758,
        'nll_SM' : 1.244758
    }
],
'Total xsec for missing topologies (fb)' : 751.7658,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 226.3577,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 164.9515,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 106.5262,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.2631,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 43.27708,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.79041,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33.78991,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 15.47225,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.08043,
        'SMS' : 'PV > (nu,l,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.57306,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 751.7658,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 226.3577,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 164.9515,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 106.5262,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.2631,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 43.27708,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.79041,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33.78991,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 15.47225,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.08043,
        'SMS' : 'PV > (nu,l,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.57306,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}