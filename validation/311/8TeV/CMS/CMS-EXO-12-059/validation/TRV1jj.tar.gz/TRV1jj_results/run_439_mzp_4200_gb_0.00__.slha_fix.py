smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 0.5,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : 'slhaFiles_Lept_gqp/run_01_mzp_1200_gb_0.01__.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'slhaFiles_Lept_gqp/run_439_mzp_4200_gb_0.00__.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1)',
        'Masses (GeV)' : [('y1', 4200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 4250.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 4200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 2130.0}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 4200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 709.0}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 4200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 709.0}
    },
    {
        'ID' : 5,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 4200.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 709.0}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2834.874,
        'upper limit (fb)' : 1.33333,
        'expected upper limit (fb)' : 2.6465,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('y1', 4200.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 2126.161,
        'r_expected' : 1071.179,
        'Width (GeV)' : [('y1', 1.3926e-12)],
        'TxNames weights (fb)' : {'TRV1qq': 2834.87403732}
    }
],
'Total xsec for missing topologies (fb)' : 1417.425,
'missing topologies' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 708.7185,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 708.7066,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 18.69259,
'missing topologies with displaced decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 12.46176,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 3.115441,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 3.115389,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with prompt decays (fb)' : 4233.607,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 2822.412,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 705.6031,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 705.5912,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}