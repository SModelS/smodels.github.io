smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 0.5,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : 'slhaFiles_Lept_gqp/run_01_mzp_1200_gb_0.01__.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'slhaFiles_Lept_gqp/run_442_mzp_4400_gb_0.00__.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1)',
        'Masses (GeV)' : [('y1', 4400.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 1900.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 4400.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 948.0}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 4400.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 316.0}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 4400.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 316.0}
    },
    {
        'ID' : 5,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 4400.0)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 316.0}
    }
],
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1263.603,
        'upper limit (fb)' : 1.05,
        'expected upper limit (fb)' : 2.26307,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('y1', 4400.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 1203.432,
        'r_expected' : 558.358,
        'Width (GeV)' : [('y1', 1.4589e-12)],
        'TxNames weights (fb)' : {'TRV1qq': 1263.60328536}
    }
],
'Total xsec for missing topologies (fb)' : 631.7971,
'missing topologies' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 315.9008,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 315.8963,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 6.434425,
'missing topologies with displaced decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 4.289627,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 1.072407,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 1.072391,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with prompt decays (fb)' : 1888.966,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 1259.314,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 314.8284,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 314.8239,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}