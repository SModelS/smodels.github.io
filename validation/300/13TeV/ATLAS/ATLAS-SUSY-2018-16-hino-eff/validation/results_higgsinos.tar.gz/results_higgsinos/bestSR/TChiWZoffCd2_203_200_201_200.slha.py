smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.001,
    'minmassgap' : 10.0,
    'maxcond' : 0.2,
    'ncpus' : 7,
    'model' : 'share.models.mssm',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'ignorepromptqnumbers' : 'spin,eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'testcoverage' : True,
    'computestatistics' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodels-utils/slha/TChi_nonDegenHinoLSP_BRN2toZN1100/TChiWZoffCd2_203_200_201_200.slha',
    'database version' : '2.1.0',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01046564,
        'upper limit (fb)' : 0.1953,
        'expected upper limit (fb)' : 0.2062,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : 'SR_ewk_2l_high',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.05358753,
        'r_expected' : 0.05075482,
        'Width (GeV)' : None,
        'nll' : 6.508682,
        'nll_min' : 6.483326,
        'nll_SM' : 6.483326
    }
],
'Total xsec for missing topologies (fb)' : 866.3895,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 866.3895,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 866.3895,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 866.3895,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}