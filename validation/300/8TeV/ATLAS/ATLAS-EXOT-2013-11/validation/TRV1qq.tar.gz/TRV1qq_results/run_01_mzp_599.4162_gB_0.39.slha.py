smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 50,
    'maxcond' : 0.2,
    'ncpus' : 1,
    'model' : 'TRV1qq_slha/run_42_MZp_649_gB_4.599776E-01.slha',
    'promptwidth' : 1.0,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 0,
    'warnings' : 'Input file ok',
    'input file' : 'TRV1qq_slha/run_01_mzp_599.4162_gB_0.39.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'SMS Decomposition' : [
    {
        'ID' : 1,
        'SMS' : '(PV > y1)',
        'Masses (GeV)' : [('y1', 599.4)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 3460.0}
    },
    {
        'ID' : 2,
        'SMS' : '(PV > y1(1)), (y1(1) > q,q)',
        'Masses (GeV)' : [('y1', 599.4)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 1740.0}
    },
    {
        'ID' : 3,
        'SMS' : '(PV > y1(1)), (y1(1) > c,c)',
        'Masses (GeV)' : [('y1', 599.4)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 581.0}
    },
    {
        'ID' : 4,
        'SMS' : '(PV > y1(1)), (y1(1) > t-,t+)',
        'Masses (GeV)' : [('y1', 599.4)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 554.0}
    },
    {
        'ID' : 5,
        'SMS' : '(PV > y1(1)), (y1(1) > b,b)',
        'Masses (GeV)' : [('y1', 599.4)],
        'PIDs' : [('y1', 5000001)],
        'Weights (fb)' : {'xsec 8.0 TeV': 581.0}
    }
],
'Total xsec for missing topologies (fb)' : 1134.839,
'missing topologies' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 580.8403,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 553.9991,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 3458.201,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 2323.361,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 580.8403,
        'SMS' : 'PV > (b,b)',
        'SMS IDs' : [5]
    },
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 553.9991,
        'SMS' : 'PV > (t,t)',
        'SMS IDs' : [4]
    }
],
'Total xsec for topologies outside the grid (fb)' : 2323.361,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 8.0,
        'weight (fb)' : 2323.361,
        'SMS' : 'PV > (jet,jet)',
        'SMS IDs' : [2, 3]
    }
]
}